﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class use_displayvb
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.top_left = New System.Windows.Forms.PictureBox()
        Me.bottom_left = New System.Windows.Forms.PictureBox()
        Me.bottom_right = New System.Windows.Forms.PictureBox()
        Me.top_right = New System.Windows.Forms.PictureBox()
        Me.txt_time_left = New System.Windows.Forms.RichTextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.btn_restart_clock = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.txt_yaw = New System.Windows.Forms.RichTextBox()
        Me.txt_pitch = New System.Windows.Forms.RichTextBox()
        Me.btn_maunaly_set_image = New System.Windows.Forms.Button()
        Me.btn_quit_game = New System.Windows.Forms.Button()
        CType(Me.top_left, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bottom_left, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bottom_right, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.top_right, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'top_left
        '
        Me.top_left.BackColor = System.Drawing.Color.Transparent
        Me.top_left.Location = New System.Drawing.Point(12, 12)
        Me.top_left.Name = "top_left"
        Me.top_left.Size = New System.Drawing.Size(204, 153)
        Me.top_left.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.top_left.TabIndex = 0
        Me.top_left.TabStop = False
        '
        'bottom_left
        '
        Me.bottom_left.BackColor = System.Drawing.Color.Transparent
        Me.bottom_left.ErrorImage = Nothing
        Me.bottom_left.Location = New System.Drawing.Point(12, 174)
        Me.bottom_left.Name = "bottom_left"
        Me.bottom_left.Size = New System.Drawing.Size(204, 153)
        Me.bottom_left.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.bottom_left.TabIndex = 1
        Me.bottom_left.TabStop = False
        '
        'bottom_right
        '
        Me.bottom_right.BackColor = System.Drawing.Color.Transparent
        Me.bottom_right.ErrorImage = Nothing
        Me.bottom_right.Location = New System.Drawing.Point(222, 171)
        Me.bottom_right.Name = "bottom_right"
        Me.bottom_right.Size = New System.Drawing.Size(204, 153)
        Me.bottom_right.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.bottom_right.TabIndex = 2
        Me.bottom_right.TabStop = False
        '
        'top_right
        '
        Me.top_right.BackColor = System.Drawing.Color.Transparent
        Me.top_right.ErrorImage = Nothing
        Me.top_right.Location = New System.Drawing.Point(222, 12)
        Me.top_right.Name = "top_right"
        Me.top_right.Size = New System.Drawing.Size(204, 153)
        Me.top_right.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.top_right.TabIndex = 3
        Me.top_right.TabStop = False
        '
        'txt_time_left
        '
        Me.txt_time_left.Location = New System.Drawing.Point(447, 53)
        Me.txt_time_left.Name = "txt_time_left"
        Me.txt_time_left.Size = New System.Drawing.Size(134, 62)
        Me.txt_time_left.TabIndex = 4
        Me.txt_time_left.Text = ""
        '
        'Timer1
        '
        '
        'btn_restart_clock
        '
        Me.btn_restart_clock.Location = New System.Drawing.Point(453, 139)
        Me.btn_restart_clock.Name = "btn_restart_clock"
        Me.btn_restart_clock.Size = New System.Drawing.Size(128, 25)
        Me.btn_restart_clock.TabIndex = 5
        Me.btn_restart_clock.Text = "Restart"
        Me.btn_restart_clock.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'txt_yaw
        '
        Me.txt_yaw.Location = New System.Drawing.Point(456, 217)
        Me.txt_yaw.Name = "txt_yaw"
        Me.txt_yaw.Size = New System.Drawing.Size(107, 33)
        Me.txt_yaw.TabIndex = 6
        Me.txt_yaw.Text = ""
        Me.txt_yaw.Visible = False
        '
        'txt_pitch
        '
        Me.txt_pitch.Location = New System.Drawing.Point(454, 256)
        Me.txt_pitch.Name = "txt_pitch"
        Me.txt_pitch.Size = New System.Drawing.Size(109, 39)
        Me.txt_pitch.TabIndex = 7
        Me.txt_pitch.Text = ""
        Me.txt_pitch.Visible = False
        '
        'btn_maunaly_set_image
        '
        Me.btn_maunaly_set_image.Location = New System.Drawing.Point(448, 177)
        Me.btn_maunaly_set_image.Name = "btn_maunaly_set_image"
        Me.btn_maunaly_set_image.Size = New System.Drawing.Size(115, 23)
        Me.btn_maunaly_set_image.TabIndex = 8
        Me.btn_maunaly_set_image.Text = "manualy set image"
        Me.btn_maunaly_set_image.UseVisualStyleBackColor = True
        Me.btn_maunaly_set_image.Visible = False
        '
        'btn_quit_game
        '
        Me.btn_quit_game.Location = New System.Drawing.Point(456, 301)
        Me.btn_quit_game.Name = "btn_quit_game"
        Me.btn_quit_game.Size = New System.Drawing.Size(124, 22)
        Me.btn_quit_game.TabIndex = 9
        Me.btn_quit_game.Text = "quit"
        Me.btn_quit_game.UseVisualStyleBackColor = True
        '
        'use_displayvb
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(603, 339)
        Me.Controls.Add(Me.btn_quit_game)
        Me.Controls.Add(Me.btn_maunaly_set_image)
        Me.Controls.Add(Me.txt_pitch)
        Me.Controls.Add(Me.txt_yaw)
        Me.Controls.Add(Me.btn_restart_clock)
        Me.Controls.Add(Me.top_right)
        Me.Controls.Add(Me.txt_time_left)
        Me.Controls.Add(Me.bottom_right)
        Me.Controls.Add(Me.bottom_left)
        Me.Controls.Add(Me.top_left)
        Me.Name = "use_displayvb"
        Me.Text = "Dispaly Board"
        CType(Me.top_left, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bottom_left, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bottom_right, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.top_right, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents top_left As PictureBox
    Friend WithEvents bottom_left As PictureBox
    Friend WithEvents bottom_right As PictureBox
    Friend WithEvents top_right As PictureBox
    Friend WithEvents txt_time_left As RichTextBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents btn_restart_clock As Button
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents txt_yaw As RichTextBox
    Friend WithEvents txt_pitch As RichTextBox
    Friend WithEvents btn_maunaly_set_image As Button
    Friend WithEvents btn_quit_game As Button
End Class
