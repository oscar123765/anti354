﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.btn_one_forwad = New System.Windows.Forms.Button()
        Me.btn_one_back = New System.Windows.Forms.Button()
        Me.btn_two_farwad = New System.Windows.Forms.Button()
        Me.btn_two_back = New System.Windows.Forms.Button()
        Me.btn_usser_input_to_game = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lbl_comp_port = New System.Windows.Forms.Label()
        Me.lbl_baud_rate = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.txt_file_dialog = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Button1.Location = New System.Drawing.Point(225, 105)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 50)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Init"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Button2.Location = New System.Drawing.Point(355, 56)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 50)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Write"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'ComboBox1
        '
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(40, 39)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 28)
        Me.ComboBox1.TabIndex = 3
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.RichTextBox1.Location = New System.Drawing.Point(98, 334)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(113, 32)
        Me.RichTextBox1.TabIndex = 4
        Me.RichTextBox1.Text = ""
        Me.RichTextBox1.Visible = False
        '
        'RichTextBox2
        '
        Me.RichTextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.RichTextBox2.Location = New System.Drawing.Point(246, 334)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(83, 32)
        Me.RichTextBox2.TabIndex = 5
        Me.RichTextBox2.Text = ""
        Me.RichTextBox2.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label1.Location = New System.Drawing.Point(106, 302)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 20)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Input"
        Me.Label1.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label2.Location = New System.Drawing.Point(242, 302)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 20)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Output"
        Me.Label2.Visible = False
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Button4.Location = New System.Drawing.Point(12, 334)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(70, 27)
        Me.Button4.TabIndex = 8
        Me.Button4.Text = "Close"
        Me.Button4.UseVisualStyleBackColor = True
        Me.Button4.Visible = False
        '
        'SerialPort1
        '
        Me.SerialPort1.PortName = "COM6"
        '
        'ComboBox2
        '
        Me.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"9600", "38400", "57600", "115200"})
        Me.ComboBox2.Location = New System.Drawing.Point(40, 105)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 28)
        Me.ComboBox2.TabIndex = 9
        '
        'btn_one_forwad
        '
        Me.btn_one_forwad.Location = New System.Drawing.Point(65, 182)
        Me.btn_one_forwad.Name = "btn_one_forwad"
        Me.btn_one_forwad.Size = New System.Drawing.Size(73, 35)
        Me.btn_one_forwad.TabIndex = 10
        Me.btn_one_forwad.Text = "up"
        Me.btn_one_forwad.UseVisualStyleBackColor = True
        '
        'btn_one_back
        '
        Me.btn_one_back.Location = New System.Drawing.Point(65, 260)
        Me.btn_one_back.Name = "btn_one_back"
        Me.btn_one_back.Size = New System.Drawing.Size(73, 35)
        Me.btn_one_back.TabIndex = 11
        Me.btn_one_back.Text = "Down"
        Me.btn_one_back.UseVisualStyleBackColor = True
        '
        'btn_two_farwad
        '
        Me.btn_two_farwad.Location = New System.Drawing.Point(12, 223)
        Me.btn_two_farwad.Name = "btn_two_farwad"
        Me.btn_two_farwad.Size = New System.Drawing.Size(54, 35)
        Me.btn_two_farwad.TabIndex = 12
        Me.btn_two_farwad.Text = "left"
        Me.btn_two_farwad.UseVisualStyleBackColor = True
        '
        'btn_two_back
        '
        Me.btn_two_back.Location = New System.Drawing.Point(138, 223)
        Me.btn_two_back.Name = "btn_two_back"
        Me.btn_two_back.Size = New System.Drawing.Size(73, 35)
        Me.btn_two_back.TabIndex = 13
        Me.btn_two_back.Text = "Right"
        Me.btn_two_back.UseVisualStyleBackColor = True
        '
        'btn_usser_input_to_game
        '
        Me.btn_usser_input_to_game.Location = New System.Drawing.Point(246, 217)
        Me.btn_usser_input_to_game.Name = "btn_usser_input_to_game"
        Me.btn_usser_input_to_game.Size = New System.Drawing.Size(172, 46)
        Me.btn_usser_input_to_game.TabIndex = 14
        Me.btn_usser_input_to_game.Text = "Start Game Now"
        Me.btn_usser_input_to_game.UseVisualStyleBackColor = True
        Me.btn_usser_input_to_game.Visible = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 120000
        '
        'lbl_comp_port
        '
        Me.lbl_comp_port.AutoSize = True
        Me.lbl_comp_port.Location = New System.Drawing.Point(37, 9)
        Me.lbl_comp_port.Name = "lbl_comp_port"
        Me.lbl_comp_port.Size = New System.Drawing.Size(393, 13)
        Me.lbl_comp_port.TabIndex = 15
        Me.lbl_comp_port.Text = "Please can you select the comp port of you android device from the drop down list" &
    ""
        '
        'lbl_baud_rate
        '
        Me.lbl_baud_rate.AutoSize = True
        Me.lbl_baud_rate.Location = New System.Drawing.Point(9, 76)
        Me.lbl_baud_rate.Name = "lbl_baud_rate"
        Me.lbl_baud_rate.Size = New System.Drawing.Size(306, 13)
        Me.lbl_baud_rate.TabIndex = 16
        Me.lbl_baud_rate.Text = "Please select the board rate of 9600 if you are useing the board"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(28, 158)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(394, 13)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Plese make sure that the board is level befor you start by useing the buttons bel" &
    "ow"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(494, 72)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 13)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "Label4"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'txt_file_dialog
        '
        Me.txt_file_dialog.Location = New System.Drawing.Point(463, 147)
        Me.txt_file_dialog.Name = "txt_file_dialog"
        Me.txt_file_dialog.Size = New System.Drawing.Size(287, 20)
        Me.txt_file_dialog.TabIndex = 19
        Me.txt_file_dialog.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(497, 211)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(265, 93)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 20
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.ClientSize = New System.Drawing.Size(436, 307)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.txt_file_dialog)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lbl_baud_rate)
        Me.Controls.Add(Me.lbl_comp_port)
        Me.Controls.Add(Me.btn_usser_input_to_game)
        Me.Controls.Add(Me.btn_two_back)
        Me.Controls.Add(Me.btn_two_farwad)
        Me.Controls.Add(Me.btn_one_back)
        Me.Controls.Add(Me.btn_one_forwad)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.RichTextBox2)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Setup the connection to the board"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents btn_one_forwad As Button
    Friend WithEvents btn_one_back As Button
    Friend WithEvents btn_two_farwad As Button
    Friend WithEvents btn_two_back As Button
    Friend WithEvents btn_usser_input_to_game As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents lbl_comp_port As Label
    Friend WithEvents lbl_baud_rate As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents txt_file_dialog As TextBox
    Friend WithEvents PictureBox1 As PictureBox
End Class
