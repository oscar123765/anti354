inside this folder you will have 2 jpeg images 
	one of the arduino wireing diagram witch will include pinouts
	the outher image looks at the system as a hole and how it is fillted down
Also there is a Board images folder THis is the folder with you need to select when the program fist starts
there is a copy of the aruinio code witch will need to be uploaded to the board via the arduinio IDE
 as well as the code on a notepad equilivent for the android code
There is also the visual studio file for the progect


----------------------------------------------------------
Youtube and web links

facebook page
https://www.facebook.com/ROBOTMAZEManiac/

youtube playthrough
https://www.youtube.com/watch?v=21b9TmMs2DQ

softwere to control board
https://www.youtube.com/watch?v=0jftn5KdBCE

wireing of the board
https://www.youtube.com/watch?v=21b9TmMs2DQ

website
https://oscar8841.wixsite.com/robotmazemaniac
-------------------------------------------------------------